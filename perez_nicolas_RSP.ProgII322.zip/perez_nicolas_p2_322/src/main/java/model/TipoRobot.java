
package model;

public enum TipoRobot {
    RECOLECTOR,
    SENSORIAL,
    GEOLOGICO,
    ASISTENCIA,
    TOPOGRAFICO
}
