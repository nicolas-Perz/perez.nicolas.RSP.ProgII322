
package model;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import service.Almacenable;

public class Inventario<T extends RobotMarte> implements Almacenable<T> {

    private List<T> lista = new ArrayList<>();

    @Override
    public void agregar(T elemento) {
        lista.add(elemento);
    }

    @Override
    public void eliminarSegun(Predicate<T> criterio) {
        Iterator<T> iterador = lista.iterator();
        
        while(iterador.hasNext()){
            if(criterio.test(iterador.next())){
                iterador.remove();
            }
        }
        
    }

    @Override
    public List<T> obtenerTodos() {
        return new ArrayList<>(lista);
    }

    @Override
    public T buscar(Predicate<T> criterio) {
        T toReturn = null;
        boolean encontrado = false;
        
        while(!encontrado){
            for(T elemento : lista){
                if(criterio.test(elemento)){
                    toReturn = elemento;
                    encontrado = true;
                }
            }
        }
        
        return toReturn;
    }

    @Override
    public void ordenar() {
        ordenar(null);
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        lista.sort(comparador);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> listaFiltrada = new ArrayList<>();
        
        for(T elemento : lista){
            if(criterio.test(elemento)){
                listaFiltrada.add(elemento);
            }
        }
        return listaFiltrada;
    }

    @Override
    public List<T> transformar(Function<T, T> operador) {
        List<T> listaTransformada = new ArrayList<>();
        
        for(T elemento : lista){
            listaTransformada.add(operador.apply(elemento));
        }
        
        return listaTransformada;
    }

    @Override
    public int contar(Predicate<T> criterio) {
        int contador = 0;
        for(T elemento : lista){
            if(criterio.test(elemento)){
                contador++;
            }
        }
        return contador;
    }

    @Override
    public void guardarEnBinario(String ruta) throws Exception {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(ruta))) {
            
            serializador.writeObject(lista);
            
        } catch(IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String ruta) throws Exception {
        try (ObjectInputStream deserializador = new ObjectInputStream(new FileInputStream(ruta))){
            
            lista =  (List<T>) deserializador.readObject();
            
        } catch(ClassNotFoundException | IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void guardarEnCSV(String ruta) throws Exception {
        
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {
            
            for(T elemento : lista){
                escritor.write(elemento.toCSV() + '\n');
            }
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        
    }

    @Override
    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws Exception {
        lista.clear();
        
        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {
            
            String linea = lector.readLine();
            while ((linea = lector.readLine()) != null){
                lista.add(fromCSV.apply(linea));
            }
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void guardarEnJSON(String ruta) throws Exception {
        
        Gson lectorJson = new Gson();
        lectorJson.toJson(ruta);
        
    }
    
    
    
}
