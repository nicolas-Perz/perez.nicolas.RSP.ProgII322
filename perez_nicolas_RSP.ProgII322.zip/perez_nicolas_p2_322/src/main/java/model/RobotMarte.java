
package model;

import persistencia.CSVConvertible;

public class RobotMarte implements CSVConvertible, Comparable<RobotMarte> {

    private int id;
    private String nombre;
    private TipoRobot tipo;
    private int nivelBateria;
    private int anioFabricacion;
    private double kmRecorridos;

    public RobotMarte(int id, String nombre, TipoRobot tipo, int nivelBateria, int anioFabricacion, double kmRecorridos) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.nivelBateria = nivelBateria;
        this.anioFabricacion = anioFabricacion;
        this.kmRecorridos = kmRecorridos;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoRobot getTipo() {
        return tipo;
    }

    public int getNivelBateria() {
        return nivelBateria;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }

    public double getKmRecorridos() {
        return kmRecorridos;
    }

    @Override
    public int compareTo(RobotMarte o) {
        int toReturn = Integer.compare( nivelBateria, o.nivelBateria);
        if(toReturn == 0){
            toReturn = Double.compare(o.kmRecorridos, kmRecorridos);
        }
        return toReturn;
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + tipo + "," + nivelBateria + "," + anioFabricacion + "," + kmRecorridos; 
    }
    
    public static String toHeaderCSV(){
        return "id,nombre,tipo,nivelBateria,anioFabricacion,kmRecorrido";
    }

    public static RobotMarte fromCSV(String linea){
        String[] atributos = linea.split(",");
        return new RobotMarte(Integer.parseInt(atributos[0]),atributos[1],TipoRobot.valueOf(atributos[2]),Integer.parseInt(atributos[3]),Integer.parseInt(atributos[4]),Double.parseDouble(atributos[5]));
    }

    @Override
    public String toString() {
        return "RobotMarte{" + "id=" + id + ", nombre=" + nombre + ", tipo=" + tipo + ", nivelBateria=" + nivelBateria + ", anioFabricacion=" + anioFabricacion + ", kmRecorridos=" + kmRecorridos + '}';
    }
    
    
    
    
}
