
package com.mycompany.perez_nicolas_p2_322;

import java.util.List;
import model.Inventario;
import model.RobotMarte;
import model.TipoRobot;
import service.Almacenable;

public class Perez_nicolas_p2_322 {

    public static void main(String[] args) {

    try {
        Almacenable<RobotMarte> inv = new Inventario<>();

        inv.agregar(new RobotMarte(101, "Ares-1", TipoRobot.RECOLECTOR, 85, 2019, 123.5));
        inv.agregar(new RobotMarte(102, "Vulcan-7", TipoRobot.SENSORIAL, 40, 2020, 88.2));
        inv.agregar(new RobotMarte(103, "GeoMax", TipoRobot.GEOLOGICO, 25, 2017, 210.4));
        inv.agregar(new RobotMarte(104, "TopoTrack", TipoRobot.TOPOGRAFICO, 77, 2021, 156.0));
        inv.agregar(new RobotMarte(105, "HelperX", TipoRobot.ASISTENCIA, 50, 2018, 95.3));
        inv.agregar(new RobotMarte(106, "Ares-2", TipoRobot.RECOLECTOR, 33, 2016, 178.9));

        System.out.println("=== Inventario Original ===");
        for (RobotMarte r : inv.obtenerTodos()) {
            System.out.println(r);
        }

        // 1) Orden natural
        inv.ordenar();
        System.out.println("\n=== Orden Natural ===");
        for (RobotMarte r : inv.obtenerTodos()) {
            System.out.println(r);
        }

        // 2) Ordenar por nombre → completar Comparator
        inv.ordenar( (a,b) -> { return a.getNombre().compareTo(b.getNombre()); } );
        System.out.println("\n=== Ordenados por Nombre ===");
        for (RobotMarte r : inv.obtenerTodos()) {
            System.out.println(r);
        }

        // 3) Filtrar robots con batería < 30 → completar Predicate
        System.out.println("\n=== Robots con Batería < 30% ===");
        List<RobotMarte> criticos = inv.filtrar( (a) -> { return a.getNivelBateria() < 30.0; });
        for (RobotMarte r : criticos) {
            System.out.println(r);
        }

        // 4) Transformar RECOLECTOR → +20% km → completar Function
        System.out.println("\n=== Transformación RECOLECTORES ===");
        List<RobotMarte> transformados = inv.transformar( (a) -> { 
            if(a.getTipo().equals(TipoRobot.RECOLECTOR)){  a = new RobotMarte(a.getId(),a.getNombre(),a.getTipo(),a.getNivelBateria(),a.getAnioFabricacion(),a.getKmRecorridos() * 1.2);} 
            return a; } );
        
        for (RobotMarte r : transformados) {
           System.out.println(r);
        }

        // 5) Contar robots fabricados antes de 2018 → completar Predicate
        int antiguos = inv.contar( (a) -> { return a.getAnioFabricacion() < 2018; } );
        System.out.println("\nRobots fabricados antes de 2018: " + antiguos);

        // Persistencias
        inv.guardarEnBinario("src\\main\\java\\resources\\robots.bin");
        inv.guardarEnCSV("src\\main\\java\\resources\\robots.csv");
        inv.guardarEnJSON("src\\main\\java\\resources\\robots.json");

        // Carga desde CSV
        Almacenable<RobotMarte> invCSV = new Inventario<>();
        invCSV.cargarDesdeCSV("src\\main\\java\\resources\\robots.csv", (a) -> { return RobotMarte.fromCSV(a); } );
        
        System.out.println("\n=== Inventario cargado desde CSV ===");
        for (RobotMarte r : invCSV.obtenerTodos()) {
            System.out.println(r);
        }

    } catch (Exception e) {
        System.err.println(e.getMessage());
    }
}


        
    }
